                                                               OS systems

•	MS1
     We created scripts that initiates empty dynamic allocator, makes BF NF FF dynamic allocation & insert with merge empty memory blocks.



•	MS2
     We created scripts that makes chunk operations like copy & paste , cut & paste , delete , share chunks in ram.
     We created scripts in makes processes in kheap  like allocating & free chunks , initialize dynamic block in kernel heap.


•	MS3
     We created scripts that makes placement and replacement in the ram to handle the page faults.
     We created scripts that preform create , get and free shared objects. 
     We created scripts that initialize dynamic allocator , allocate & free memory block in the user side.
     We created a script that preforms semaphores signals , semaphores wait 
	 